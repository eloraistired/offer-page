import Image from 'next/image';
import logo from './logo.png';
import { Button } from '../ui/button';

export const Header = () => {
  return (
    <header className="flex items-center justify-between py-4 px-4 md:px-8 sticky top-0 bg-white/95 backdrop-blur z-30">
      <div className="flex items-center gap-2">
        <h1 className="w-[100px]">
          <Image src={logo} alt="Funnel Liner" width={100} height={100} />
        </h1>
        <div className="text-xs px-2.5 py-0.5 rounded font-semibold bg-secondary-background text-primary">v1.3</div>
      </div>
    </header>
  );
};
